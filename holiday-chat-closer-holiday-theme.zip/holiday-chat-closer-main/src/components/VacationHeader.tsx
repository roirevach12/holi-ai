import { Calendar, MessageCircle, Users, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
export const VacationHeader = () => {
  return <header className="w-full border-b border-white/10 backdrop-blur-md bg-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img 
              src="/lovable-uploads/60893c0a-a897-465d-a711-8fe93347c50b.png?v=2" 
              alt="Holi.ai Logo" 
              className="h-12 w-auto"
            />
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors">
              קהילה
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors">
              תמחור
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors">
              ארגוני
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors">
              למד
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors">
              השקות
            </a>
          </nav>

          {/* CTA */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" className="text-gray-700 hover:bg-gray-100">
              קבל קרדיטים בחינם
            </Button>
            <Button variant="hero" className="font-medium">
              צ'אט חופשות של רול
            </Button>
          </div>
        </div>
      </div>
    </header>;
};
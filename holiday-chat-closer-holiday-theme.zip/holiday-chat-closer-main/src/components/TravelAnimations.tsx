import { Plane, Palmtree, Sun, Camera, MapPin, Compass, Umbrella, Mountain } from "lucide-react";

export const TravelAnimations = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Flying planes */}
      <div className="absolute top-20 left-0 animate-[fly_15s_linear_infinite]">
        <Plane className="w-8 h-8 text-vacation-orange opacity-60" />
      </div>
      <div className="absolute top-40 right-0 animate-[fly-reverse_12s_linear_infinite_3s]">
        <Plane className="w-6 h-6 text-vacation-orange opacity-40 rotate-180" />
      </div>
      
      {/* Floating palm trees */}
      <div className="absolute bottom-32 left-16 animate-[float_8s_ease-in-out_infinite]">
        <Palmtree className="w-12 h-12 text-vacation-orange opacity-50" />
      </div>
      <div className="absolute bottom-20 right-20 animate-[float_6s_ease-in-out_infinite_2s]">
        <Palmtree className="w-10 h-10 text-vacation-orange opacity-40" />
      </div>
      
      {/* Rotating suns */}
      <div className="absolute top-16 right-32 animate-[spin_20s_linear_infinite]">
        <Sun className="w-10 h-10 text-vacation-orange opacity-30" />
      </div>
      <div className="absolute top-60 left-32 animate-[spin_15s_linear_infinite_reverse]">
        <Sun className="w-8 h-8 text-vacation-orange opacity-40" />
      </div>
      
      {/* Bouncing cameras */}
      <div className="absolute bottom-40 left-1/3 animate-[bounce_4s_ease-in-out_infinite]">
        <Camera className="w-6 h-6 text-vacation-orange opacity-60" />
      </div>
      
      {/* Pulsing compass */}
      <div className="absolute top-32 left-1/4 animate-[pulse_3s_ease-in-out_infinite]">
        <Compass className="w-8 h-8 text-vacation-orange opacity-50" />
      </div>
      
      {/* Floating umbrellas */}
      <div className="absolute bottom-60 right-1/3 animate-[float_7s_ease-in-out_infinite_1s]">
        <Umbrella className="w-9 h-9 text-vacation-orange opacity-45" />
      </div>
      
      {/* Moving map pins */}
      <div className="absolute top-48 right-16 animate-[wiggle_4s_ease-in-out_infinite]">
        <MapPin className="w-7 h-7 text-vacation-orange opacity-55" />
      </div>
      <div className="absolute bottom-48 left-1/2 animate-[wiggle_5s_ease-in-out_infinite_2s]">
        <MapPin className="w-6 h-6 text-vacation-orange opacity-45" />
      </div>
      
      {/* Mountains */}
      <div className="absolute top-72 left-20 animate-[float_10s_ease-in-out_infinite]">
        <Mountain className="w-11 h-11 text-vacation-orange opacity-35" />
      </div>
    </div>
  );
};
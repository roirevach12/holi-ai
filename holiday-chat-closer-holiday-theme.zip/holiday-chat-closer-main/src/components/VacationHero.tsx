
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowUp, Calendar, Phone, Sparkles, Headphones, Map, Mountain, Waves, Trees, Sun, Snowflake, Plane, Car, Train, Hotel, Home, MapPin, Users, User, Heart, Star } from "lucide-react";

export const VacationHero = () => {
  const [message, setMessage] = useState("");
  const [isChatMode, setIsChatMode] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [chatHistory, setChatHistory] = useState<{question: string, answer: string}[]>([]);

  const questions = [
    {
      question: "? לאן תרצה לברוח היום",
      options: [
        { icon: Map, label: "אסיה", value: "אסיה" },
        { icon: Mountain, label: "אירופה", value: "אירופה" },
        { icon: Waves, label: "אפריקה", value: "אפריקה" },
        { icon: Trees, label: "אמריקה", value: "אמריקה" },
        { icon: Mountain, label: "אוקיאניה", value: "אוקיאניה" },
        { icon: Snowflake, label: "אנטרקטיקה", value: "אנטרקטיקה" }
      ]
    },
    {
      question: "? איך תרצה להגיע",
      options: [
        { icon: Plane, label: "טיסה", value: "טיסה" },
        { icon: Car, label: "רכב", value: "רכב" },
        { icon: Train, label: "רכבת", value: "רכבת" },
        { icon: Map, label: "שייט", value: "שייט" },
        { icon: Mountain, label: "הליכה", value: "הליכה" },
        { icon: Waves, label: "אופניים", value: "אופניים" }
      ]
    },
    {
      question: "? איפה תרצה לישון",
      options: [
        { icon: Hotel, label: "מלון", value: "מלון" },
        { icon: Home, label: "וילה", value: "וילה" },
        { icon: MapPin, label: "קמפינג", value: "קמפינג" },
        { icon: Mountain, label: "הוסטל", value: "הוסטל" },
        { icon: Star, label: "ריזורט", value: "ריזורט" },
        { icon: Trees, label: "איירבנב", value: "איירבנב" }
      ]
    },
    {
      question: "? עם מי תרצה לטוס",
      options: [
        { icon: User, label: "לבד", value: "לבד" },
        { icon: Heart, label: "זוג", value: "עם בן/בת זוג" },
        { icon: Users, label: "משפחה", value: "עם המשפחה" },
        { icon: Star, label: "חברים", value: "עם חברים" },
        { icon: Sun, label: "קבוצה", value: "עם קבוצה" },
        { icon: Map, label: "טיול מאורגן", value: "טיול מאורגן" }
      ]
    }
  ];

  const handleOptionClick = (option: {icon: any, label: string, value: string}) => {
    const currentQuestion = questions[currentQuestionIndex];
    const newChatEntry = {
      question: currentQuestion.question,
      answer: option.value
    };
    
    setChatHistory(prev => [...prev, newChatEntry]);
    
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      console.log("Sending message:", message);
      setMessage("");
    }
  };

  const handleInputFocus = () => {
    setIsChatMode(true);
  };

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="flex-1 flex flex-col px-4 py-20 relative">
      {/* Logo - moves up when chat mode is active */}
      <div className={`flex items-center justify-center mb-6 transition-all duration-700 ease-in-out ${
        isChatMode ? 'translate-y-[-80px] scale-75' : 'translate-y-0 scale-100'
      }`}>
        <img src="/lovable-uploads/60893c0a-a897-465d-a711-8fe93347c50b.png?v=2" alt="Holi.ai Logo" className="h-20 w-auto" />
      </div>

      {/* Main content - hides when chat mode is active */}
      <div className={`max-w-4xl mx-auto text-center space-y-8 transition-all duration-700 ease-in-out ${
        isChatMode ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'
      }`}>
        {/* Title */}
        <div className="space-y-4">
          <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight">
            <span className="bg-gradient-to-r from-vacation-orange to-vacation-pink bg-clip-text text-transparent">
              AI
            </span>
            {" "}נסיעות בעולם
          </h1>
          <p className="text-xl md:text-2xl text-white/80 max-w-2xl mx-auto leading-relaxed">
            תכנן ותזמן את החופשות שלך עם בינה מלאכותית מתקדמת
          </p>
        </div>
      </div>

      {/* Chat box - expands and moves to center/bottom when active */}
      <div className={`mx-auto transition-all duration-700 ease-in-out ${
        isChatMode 
          ? 'fixed inset-x-4 top-32 bottom-4 w-auto max-w-4xl left-1/2 transform -translate-x-1/2' 
          : 'w-[min(90%,760px)] relative mt-8'
      }`}>
        <form onSubmit={handleSubmit} className="h-full flex flex-col">
          <div className={`bg-gradient-card backdrop-blur-md border border-white/20 shadow-[0_8px_30px_rgb(0,0,0,0.12)] transition-all duration-700 ease-in-out ${
            isChatMode ? 'h-full flex flex-col rounded-2xl' : 'rounded-[28px] p-6'
          }`}>
            
            {/* Chat area with visual wizard */}
            {isChatMode && (
              <div className="flex-1 overflow-y-auto">
                <div className="px-6 pt-12 pb-32 scroll-pt-12"> {/* Limited dead space */}
                  
                  {/* Chat history */}
                  {chatHistory.map((entry, index) => (
                    <div key={index} className="mb-6 space-y-3">
                      <div className="text-vacation-blue font-medium text-lg">{entry.question}</div>
                      <div className="text-vacation-blue bg-white/10 rounded-lg p-3 mr-8">
                        {entry.answer}
                      </div>
                    </div>
                  ))}
                  
                  {/* Current question and options */}
                  {currentQuestionIndex < questions.length && (
                    <div className="mb-6">
                      <h2 className="text-xl font-semibold text-vacation-blue text-center mb-8">
                        {currentQuestion.question}
                      </h2>
                      
                      <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                        {currentQuestion.options.map((option, index) => (
                          <button
                            key={index}
                            onClick={() => handleOptionClick(option)}
                            className="flex flex-col items-center space-y-2 p-4 rounded-xl hover:bg-white/10 transition-colors border border-white/20 hover:border-vacation-blue"
                          >
                            <option.icon className="w-8 h-8 text-vacation-blue" />
                            <span className="text-xs text-white/80">{option.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Completion message */}
                  {currentQuestionIndex >= questions.length && (
                    <div className="text-center py-8">
                      <div className="text-vacation-blue text-lg font-medium mb-4">
                        תודה! אני מכין לך הצעות מותאמות אישית...
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Input area */}
            <div className={`${isChatMode ? 'p-6 border-t border-white/10' : ''}`}>
              <div className={`flex items-center space-x-4 rtl:space-x-reverse ${isChatMode ? '' : 'h-[66px] px-6'}`}>
                <Input 
                  value={message} 
                  onChange={e => setMessage(e.target.value)}
                  onFocus={handleInputFocus}
                  placeholder="בקש מ-Holi AI לתכנן לך את החופשה המושלמת..." 
                  className="flex-1 border-none bg-transparent text-[20px] leading-[1.5] placeholder:text-muted-foreground focus-visible:ring-0 focus-visible:ring-offset-0" 
                  dir="rtl" 
                />
                <Button 
                  type="submit" 
                  variant="vacation" 
                  size="icon" 
                  className="rounded-full w-14 h-14 shrink-0" 
                  disabled={!message.trim()}
                >
                  <ArrowUp className="w-6 h-6" />
                </Button>
              </div>

              {/* Action Buttons - only show when not in chat mode */}
              {!isChatMode && (
                <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse mt-6 pt-4 border-t border-white/10">
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                    <Phone className="w-4 h-4 mr-2" />
                    מעבר לסוכן אנושי
                  </Button>
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Supabase
                  </Button>
                </div>
              )}
            </div>
          </div>
        </form>
      </div>

      {/* Features section - moved to bottom and only shows when not in chat mode */}
      <div className={`max-w-4xl mx-auto mt-16 transition-all duration-700 ease-in-out ${
        isChatMode ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'
      }`}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6 text-center">
            <Headphones className="w-8 h-8 text-vacation-blue mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">סוכן אנושי זמין</h3>
            <p className="text-white/90 text-sm">
              בכל שלב במהלך סגירת החופשה ניתן לעבור לסוכן נסיעות אנושי
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6 text-center">
            <Sparkles className="w-8 h-8 text-vacation-purple mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">אוטומציה מלאה</h3>
            <p className="text-white/90 text-sm">הכל מתבצע אוטומטית - מיצירה ועד תשלום</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6 text-center">
            <ArrowUp className="w-8 h-8 text-vacation-orange mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-white mb-2">פשוט ומהיר</h3>
            <p className="text-white/90 text-sm">
              ממשק פשוט שמאפשר לך לסגור חופשות תוך דקות
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

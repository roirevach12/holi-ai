import { VacationHeader } from "@/components/VacationHeader";
import { VacationHero } from "@/components/VacationHero";
import { TravelAnimations } from "@/components/TravelAnimations";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-hero flex flex-col relative">
      <TravelAnimations />
      <VacationHeader />
      <VacationHero />
    </div>
  );
};

export default Index;
